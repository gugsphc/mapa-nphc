@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$t=(Resolve-Path 'mapa-nphc.html').Path;$i=(Resolve-Path 'mapa-nphc.ico').Path;$w=New-Object -ComObject WScript.Shell;foreach($d in @([Environment]::GetFolderPath('Desktop'),(Get-Location).Path)){$s=$w.CreateShortcut((Join-Path $d 'Mapa NPHC.lnk'));$s.TargetPath=$t;$s.IconLocation=$i;$s.Save()}"
echo Atalho "Mapa NPHC" criado na area de trabalho e nesta pasta.
pause
